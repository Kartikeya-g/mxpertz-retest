const schedule = require('node-schedule')

const schedulePost = (time, postCallback) => {
    schedule.scheduleJob(time, postCallback)
};

module.exports = { schedulePost }
