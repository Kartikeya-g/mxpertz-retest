const express = require('express');
const router = express.Router();
const multer = require('multer');
const { postPhoto } = require('../services/facebookService');
const { authenticateToken } = require('../middleware/auth');
const { schedulePost } = require('../utils/scheduler');

const upload = multer({ dest: 'uploads/' });

router.post('/postPhoto', authenticateToken, upload.single('photo'), async (req, res) => {
  const { message, time } = req.body;
  const photoPath = req.file.path;

  if (time) {
    schedulePost(new Date(time), async () => {
      await postPhoto(message, photoPath);
      console.log(`Scheduled photo posted: ${message}`);
    });
    res.send('Photo post scheduled successfully.');
  } else {
    const result = await postPhoto(message, photoPath);
    res.send(result);
  }
});

module.exports = router;