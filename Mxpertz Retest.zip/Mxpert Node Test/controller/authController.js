const jwt = require('jsonwebtoken')
const User = require('../models/userModel')
const dotenv = require('dotenv')

dotenv.config();

exports.register = async (req, res) => {
    const { username, email, password} = req.body;
    try {
        const user = await User.create({username, email, password});
        const token = jwt.sign({id: user._id}, process.env.JWT_SECRET, {expiresIn: '1d'})
        res.status(201).json({token});
    } catch (error) {
        res.status(400).json({error: error.message});
    }
}

exports.login = async(req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({email});
        if(!user || !(await user.matchPassword(password))) {
            return res.status(401).json({message: 'Invalid Credentials'});
        }
        const token = jwt.sign({id: user._id}, process.env.JWT_SECRET, {expiresIn: '1d'});
        res.json({token});
    }
    catch (error) {
        res.status(400).json({error: error.message});
    }
}