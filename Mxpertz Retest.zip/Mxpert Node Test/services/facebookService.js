const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');
const config = require('../config/config');

const postPhoto = async (message, photoPath) => {
  const formData = new FormData();
  formData.append('message', message);
  formData.append('access_token', config.facebook.appKey);
  formData.append('source', fs.createReadStream(photoPath));

  try {
    const response = await axios.post(`https://graph.facebook.com/v11.0/me/photos`, formData, {
      headers: {
        ...formData.getHeaders()
      }
    });
    return response.data;
  } catch (error) {
    console.error('Error posting photo:', error);
    throw error;
  }
};

module.exports = { postPhoto };