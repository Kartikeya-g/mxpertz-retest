module.exports = {
    facebook: {
        appKey: '1899457870504658',
        appSecretKey: '464dfcf123dd4a2ee644de0629bcf9de'
    }
};